package com.example.kellydemowallet
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
