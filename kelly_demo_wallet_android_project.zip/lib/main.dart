import 'package:flutter/material.dart';

void main() => runApp(const DemoWalletApp());

class DemoWalletApp extends StatelessWidget {
  const DemoWalletApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kelly Demo Wallet',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2457D6),
        scaffoldBackgroundColor: const Color(0xFFF6F7FB),
      ),
      home: const WalletHome(),
    );
  }
}

class WalletHome extends StatefulWidget {
  const WalletHome({super.key});
  @override
  State<WalletHome> createState() => _WalletHomeState();
}

class _WalletHomeState extends State<WalletHome> {
  double balance = 250000;
  final List<Map<String, dynamic>> transactions = [
    {'title': 'Demo Deposit', 'amount': 100000.0, 'date': 'Today', 'in': true},
    {'title': 'Demo Transfer', 'amount': -25000.0, 'date': 'Yesterday', 'in': false},
    {'title': 'Demo Deposit', 'amount': 75000.0, 'date': '18 Sep 2026', 'in': true},
  ];

  void addDemoMoney() {
    setState(() {
      balance += 10000;
      transactions.insert(0, {
        'title': 'Demo Deposit',
        'amount': 10000.0,
        'date': 'Just now',
        'in': true
      });
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Demo money added — no real funds involved.')),
    );
  }

  void sendDemoMoney() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Send Demo Money'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            prefixText: '₦ ',
            labelText: 'Amount',
            hintText: '1000',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final amount = double.tryParse(controller.text);
              if (amount == null || amount <= 0 || amount > balance) return;
              setState(() {
                balance -= amount;
                transactions.insert(0, {
                  'title': 'Demo Transfer',
                  'amount': -amount,
                  'date': 'Just now',
                  'in': false
                });
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Demo transfer completed locally.')),
              );
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelly Demo Wallet', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => showDialog(
              context: context,
              builder: (_) => const AlertDialog(
                title: Text('Demo Profile'),
                content: Text('Kelly Demo User\n\nThis is a fictional wallet for testing and UI demonstration only.'),
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2457D6), Color(0xFF4C7DFF)],
                  ),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('DEMO BALANCE', style: TextStyle(color: Colors.white70, letterSpacing: 1.2)),
                    const SizedBox(height: 8),
                    Text('₦${balance.toStringAsFixed(2)}',
                      style: const TextStyle(color: Colors.white, fontSize: 31, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    const Text('NO REAL MONEY • FICTIONAL DATA',
                      style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: _Action(icon: Icons.send_rounded, label: 'Send', onTap: sendDemoMoney)),
                  const SizedBox(width: 12),
                  Expanded(child: _Action(icon: Icons.download_rounded, label: 'Receive',
                    onTap: () => showDialog(context: context, builder: (_) => const AlertDialog(
                      title: Text('Receive Demo Money'),
                      content: Text('DEMO-WALLET-KELLY-0001\n\nThis address is fictional and cannot receive real funds.'),
                    )))),
                  const SizedBox(width: 12),
                  Expanded(child: _Action(icon: Icons.add_circle_outline, label: 'Add Money', onTap: addDemoMoney)),
                ],
              ),
              const SizedBox(height: 28),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Recent transactions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  TextButton(onPressed: () {}, child: const Text('See all')),
                ],
              ),
              const SizedBox(height: 4),
              ...transactions.map((tx) => Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: tx['in'] ? Colors.green.shade50 : Colors.red.shade50,
                    child: Icon(tx['in'] ? Icons.arrow_downward : Icons.arrow_upward,
                      color: tx['in'] ? Colors.green : Colors.red),
                  ),
                  title: Text(tx['title'], style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(tx['date']),
                  trailing: Text(
                    '${tx['in'] ? '+' : '-'}₦${tx['amount'].abs().toStringAsFixed(2)}',
                    style: TextStyle(fontWeight: FontWeight.bold,
                      color: tx['in'] ? Colors.green.shade700 : Colors.red.shade700),
                  ),
                ),
              )),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => showDialog(
                  context: context,
                  builder: (_) => const AlertDialog(
                    title: Text('About this app'),
                    content: Text('Kelly Demo Wallet is a fictional UI prototype. It does not connect to banks, cards, payment processors, or cryptocurrency networks.'),
                  ),
                ),
                icon: const Icon(Icons.info_outline),
                label: const Text('About Demo Wallet'),
              ),
            ],
          ),
          const IgnorePointer(
            child: Center(
              child: Opacity(
                opacity: 0.08,
                child: RotatedBox(
                  quarterTurns: 5,
                  child: Text('DEMO • NO REAL MONEY',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Action({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(children: [
        Icon(icon, color: const Color(0xFF2457D6)),
        const SizedBox(height: 7),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    ),
  );
}
